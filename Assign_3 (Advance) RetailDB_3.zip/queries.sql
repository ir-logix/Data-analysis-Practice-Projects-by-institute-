--create database RetailDB_3
-- 1. Customers
CREATE TABLE Customers (
 customer_id INT PRIMARY KEY,
 customer_name VARCHAR(30),
 email VARCHAR(40),
 city VARCHAR(20),
 signup_date DATE
);
select * from Customers;
insert into Customers values
(1,'Rohit Kumar','rohit.kumar@gmail.com','Delhi','2023-01-12'),
(2,'Sneha Sharma','sneha.sharma@yahoo.com','Mumbai','2023-02-05'),
(3,'Amit Patel','amit.patel@gmail.com','Ahmedabad','2023-02-18'),
(4,'Priya Reddy','priya.reddy@gmail.com','Hyderabad','2023-03-02'),
(5,'Karan Singh','karan.singh@outlook.com','Chennai','2023-03-15'),
(6,'Neha Verma','neha.verma@gmail.com','Pune','2023-04-01'),
(7,'Arjun Mehta','arjun.mehta@gmail.com','Bengaluru','2023-04-20'),
(8,'Ritika Gupta','ritika.gupta@yahoo.com','Kolkata','2023-05-12'),
(9,'Vikram Joshi','vikram.joshi@gmail.com','Lucknow','2023-05-25'),
(10,'Ananya Das','ananya.das@gmail.com','Bhubaneswar','2023-06-08'),
(11,'Suresh Iyer','suresh.iyer@gmail.com','Chennai','2023-06-20'),
(12,'Megha Kapoor','megha.kapoor@yahoo.com','Jaipur','2023-07-03'),
(13,'Ravi Shankar','ravi.shankar@gmail.com','Delhi','2023-07-15'),
(14,'Tanya Mishra','tanya.mishra@gmail.com','Noida','2023-08-01'),
(15,'Aditya Jain','aditya.jain@gmail.com','Indore','2023-08-14');
select * from Customers;

-- 2. Suppliers
CREATE TABLE Suppliers (
 supplier_id INT PRIMARY KEY,
 supplier_name VARCHAR(40),
 contact_email VARCHAR(40),
 city VARCHAR(20)
);
select * from Suppliers;
insert into Suppliers values
(1,'Reliance Digital','support@reliance.com','Mumbai'),
(2,'Croma Electronics','info@croma.com','Delhi'),
(3,'Flipkart Seller Hub','sellers@flipkart.com','Bengaluru'),
(4,'Amazon India Vendor','vendor@amazon.in','Hyderabad'),
(5,'Tata Cliq','support@tatacliq.com','Pune'),
(6,'Vijay Sales','sales@vijaysales.com','Chennai'),
(7,'Lifestyle Stores','info@lifestylestores.com','Kolkata'),
(8,'Metro Electronics','metro@electronics.com','Ahmedabad'),
(9,'Big Bazaar','help@bigbazaar.com','Indore'),
(10,'D-Mart Suppliers','supply@dmart.in','Nagpur'),
(11,'Shoppers Stop','contact@shoppersstop.com','Jaipur'),
(12,'Snapdeal Vendors','vendor@snapdeal.com','Noida');
select * from Suppliers;

-- 3. Shippers
CREATE TABLE Shippers (
 shipper_id INT PRIMARY KEY,
 shipper_name VARCHAR(30),
 contact VARCHAR(30)
);
select * from Shippers;
insert into Shippers values
(1,'BlueDart Express','support@bluedart.com'),
(2,'DTDC Courier','help@dtdc.com'),
(3,'Delhivery Logistics','contact@delhivery.com'),
(4,'Ekart Logistics','care@ekart.com'),
(5,'Gati Express','service@gati.com'),
(6,'India Post Speed','info@indiapost.gov.in'),
(7,'Shadowfax Delivery','support@shadowfax.in');
select * from Shippers;

-- 4. Payment Methods
CREATE TABLE Payment_Methods (
 payment_id INT PRIMARY KEY,
 payment_type VARCHAR(30) UNIQUE
);
select * from Payment_Methods;
insert into Payment_Methods values
(1,'UPI'),
(2,'Credit Card'),
(3,'Debit Card'),
(4,'Net Banking'),
(5,'Cash'),
(6,'Wallet'),
(7,'EMI');
select * from Payment_Methods;

-- 5. Products
CREATE TABLE Products (
 product_id INT PRIMARY KEY,
 product_name VARCHAR(40),
 category VARCHAR(30),
 price DECIMAL(10,2),
 stock_qty INT,
 supplier_id INT,
 FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);
select * from Products;
insert into Products values
(1,'iPhone 15','Electronics',79999,50,1),
(2,'Samsung Galaxy S24','Electronics',74999,40,2),
(3,'Noise Smartwatch','Wearables',4999,100,3),
(4,'Boat Earbuds','Wearables',2499,200,4),
(5,'Kurta Set','Fashion',1999,150,7),
(6,'Running Shoes','Fashion',2999,120,7),
(7,'Prestige Mixer Grinder','Home Appliances',6499,80,5),
(8,'Sony Bravia 55” TV','Electronics',59999,30,6),
(9,'Lenovo Laptop','Electronics',55999,45,2),
(10,'Philips Trimmer','Personal Care',1499,90,8);
select * from Products;
 
-- 6. Orders (normalized, no total_amount column)
CREATE TABLE Orders (
 order_id INT PRIMARY KEY,
 customer_id INT,
 order_date DATE,
 payment_id INT,
 shipper_id INT,
 FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
 FOREIGN KEY (payment_id) REFERENCES Payment_Methods(payment_id),
 FOREIGN KEY (shipper_id) REFERENCES Shippers(shipper_id)
);
select * from Orders;
insert into Orders values
(1,1,'2024-01-05',1,3),
(2,2,'2024-01-06',2,5),
(3,3,'2024-01-07',4,2),
(4,4,'2024-01-08',3,1),
(5,5,'2024-01-08',5,7),
(6,6,'2024-01-09',7,4),
(7,7,'2024-01-09',6,6),
(8,8,'2024-01-10',2,3),
(9,9,'2024-01-13',1,5),
(10,10,'2024-01-11',3,2),
(11,11,'2024-01-12',4,1),
(12,12,'2024-01-13',5,6),
(13,13,'2024-01-14',6,4),
(14,14,'2024-01-14',7,7),
(15,15,'2024-01-15',1,2),
(16,3,'2024-01-15',2,5),
(17,7,'2024-01-16',4,6),
(18,10,'2024-01-17',5,3),
(19,2,'2024-01-17',6,1),
(20,6,'2024-01-18',3,7),
(21,8,'2024-01-19',1,4),
(22,1,'2024-01-19',7,2),
(23,4,'2024-01-20',2,6),
(24,11,'2024-01-21',5,5),
(25,9,'2024-01-21',3,7),
(26,12,'2024-01-22',4,1),
(27,14,'2024-01-23',6,4),
(28,13,'2024-01-23',2,3),
(29,5,'2024-01-24',1,6),
(30,15,'2024-01-25',7,7),
(31,8,'2024-01-25',6,2),
(32,7,'2024-01-26',3,5),
(33,2,'2024-01-27',4,1),
(34,9,'2024-01-27',2,4),
(35,10,'2024-01-28',1,6),
(36,11,'2024-01-29',5,7),
(37,14,'2024-01-29',7,3),
(38,6,'2024-01-30',3,2),
(39,3,'2024-01-31',6,5),
(40,12,'2024-02-01',2,1),
(41,1,'2024-02-01',4,6),
(42,13,'2024-02-02',5,7),
(43,15,'2024-02-02',7,4),
(44,4,'2024-02-03',1,2),
(45,5,'2024-02-04',3,6),
(46,2,'2024-02-05',6,7),
(47,7,'2024-02-05',5,1),
(48,9,'2024-02-06',2,3),
(49,8,'2024-02-07',1,4),
(50,10,'2024-02-07',7,2),
(51,11,'2024-02-08',6,5),
(52,6,'2024-02-09',3,7),
(53,14,'2024-02-09',2,6),
(54,12,'2024-02-10',5,1),
(55,13,'2024-02-10',7,4),
(56,1,'2024-02-11',4,3),
(57,15,'2024-02-12',6,2),
(58,5,'2024-02-12',3,7),
(59,4,'2024-02-13',2,5),
(60,2,'2024-02-14',1,6),
(61,3,'2024-02-14',7,1),
(62,7,'2024-02-15',6,4),
(63,8,'2024-02-15',5,2),
(64,9,'2024-02-16',4,7),
(65,10,'2024-02-16',2,6),
(66,11,'2024-02-17',3,1),
(67,12,'2024-02-18',6,5),
(68,13,'2024-02-18',1,4),
(69,14,'2024-02-19',7,3),
(70,15,'2024-02-20',5,2),
(71,1,'2024-02-21',2,7),
(72,2,'2024-02-21',3,6),
(73,3,'2024-02-22',4,1),
(74,5,'2024-02-23',6,5),
(75,7,'2024-02-23',7,4);
select * from Orders;

-- 7. Order_Items
CREATE TABLE Order_Items (
 order_item_id INT PRIMARY KEY,
 order_id INT,
 product_id INT,
 quantity INT,
 price_each DECIMAL(10,2),
 FOREIGN KEY (order_id) REFERENCES Orders(order_id),
 FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
select * from Order_Items;
insert into Order_Items values
(1,	1,	1,	2,	15000),
(2,	2,  3,	1,	12000),
(3,	3,	5,	3,	2500),
(4,	4,	2,	1,	22000),
(5,	5,	7,	2,	1800),
(6,	6,	4,	1,	8000),
(7,	7,	6,	4,	1500),
(8,	8,	8,	2,	3500),
(9,	9,	10,	1,	7000),
(10,	10,	9,	3,	1200),
(11,	11,	2,	1,	22000),
(12,	12,	1,	2,	15000),
(13,	13,	4,	3,	8000),
(14,	14,	7,	1,	1800),
(15,	15,	5,	2,	2500),
(16,	16,	3,	2,	12000),
(17,	17,	6,	3,	1500),
(18,	18,	9,	4,	1200),
(19,	19,	8,	1,	3500),
(20,	20,	10,	2,	7000),
(21,	21,	1,	1,	15000),
(22,	22,	2,	3,	22000),
(23,	23,	5,	2,	2500),
(24,	24,	7,	1,	1800),
(25,	25,	6,	2,	1500),
(26,	26,	4,	1,	8000),
(27,	27,	3,	1,	12000),
(28,	28,	8,	2,	3500),
(29,	29,	9,	1,	1200),
(30,	30,	10,	2,	7000),
(31,	31,	1,	3,	15000),
(32,	32,	2,	1,	22000),
(33,	33,	7,	2,	1800),
(34,	34,	4,	1,	8000),
(35,	35,	6,	3,	1500),
(36,	36,	5,	2,	2500),
(37,	37,	3,	1,	12000),
(38,	38,	9,	2,	1200),
(39,	39,	8,	1,	3500),
(40,	40,	2,	2,	22000),
(41,	41,	1,	2,	15000),
(42,	42,	4,	1,	8000),
(43,	43,	6,	3,	1500),
(44,	44,	7,	2,	1800),
(45,	45,	10,	2,	7000),
(46,	46,	3,	1,	12000),
(47,	47,	5,	2,	2500),
(48,	48,	9,	3,	1200),
(49,	49,	8,	2,	3500),
(50,	50,	1,	1,	15000),
(51,	51,	4,	2,	8000),
(52,	52,	2,	1,	22000),
(53,	53,	7,	3,	1800),
(54,	54,	6,	2,	1500),
(55,	55,	5,	1, 	2500),
(56,	56,	10,	2,	7000),
(57,	57,	8,	1,	3500),
(58,	58,	9,	2,	1200),
(59,	59,	3,	1,	12000),
(60,	60,	2,	2,	22000),
(61,	61,	1,	2,	15000),
(62,	62,	4,	3,	8000),
(63,	63,	7,	2,	1800),
(64,	64,	6,	2,	1500),
(65,	65,	5,	1,	2500),
(66,	66,	9,	3,	1200),
(67,	67,	8,	1,	3500),
(68,	68,	10,	2,	7000),
(69,	69,	2,	2,	22000),
(70,	70,	1,	3,	15000),
(71,	71,	3,	1,	12000),
(72,	72,	4,	1,	8000),
(73,	73,	5,	2,	2500),
(74,	74,	7,	2,	1800),
(75,	75,	6,	3,	15000);
select * from Order_Items;
-------------------------------------------------------------------------

--Assignment_3--

--Joins, Group By, Order By and Aggregations--

--Q.1--
SELECT 
    s.shipper_name, 
    SUM(quantity * price_each) AS Total_Revenue
FROM 
    Shippers s
INNER JOIN 
    Orders o ON s.shipper_id = o.shipper_id
INNER JOIN 
    Order_Items oi ON o.order_id = oi.order_id
GROUP BY 
    s.shipper_name;

--Q.2--
SELECT c.customer_name,
       SUM(quantity * price_each) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN Order_Items oi ON o.order_id = oi.order_id
GROUP BY c.customer_name
ORDER BY total_spent DESC
offset 0 rows fetch first 5 rows only;

--Q.3--
SELECT product_id, category,
       AVG(price) AS Avg_price
FROM Products 
GROUP BY product_id, category
HAVING AVG(price) > 8000;

--Q.4--
SELECT c.city,
       COUNT(o.order_id) AS total_orders
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.city
ORDER BY total_orders DESC;

--Q.5--
SELECT s.supplier_name,
       COUNT(DISTINCT p.category) AS category_count
FROM suppliers s
JOIN products p ON s.supplier_id = p.supplier_id
GROUP BY s.supplier_name
HAVING COUNT(DISTINCT p.category) > 1;

--Q.6--
SELECT o.order_id,
       COUNT(oi.order_item_id) AS total_items
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY o.order_id;
-------------------------------------------------------------------------

--Subqueries-Nested and Correlated--

--Q.7--
SELECT c.customer_id, c.customer_name,
      SUM(oi.quantity * oi.price_each) as total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
join order_items oi on o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name
HAVING SUM(oi.quantity * oi.price_each) >
       (SELECT AVG(customer_total)
        FROM (
            SELECT SUM(quantity * price_each) AS customer_total
            FROM orders o
            join order_items oi on o.order_id = oi.order_id
            GROUP BY customer_id
            ) AS customer_totals);
--Here avg. of total_spent by Customers is 66506.666666.           

 --Q.8--             
SELECT p.product_id, p.product_name, p.category, p.price
FROM products p
WHERE p.price > (
    SELECT AVG(p2.price)
    FROM products p2
    WHERE p.category = p2.category);

--Q.9--   
SELECT DISTINCT c.customer_id, c.customer_name
FROM customers c
WHERE c.customer_id IN (
    SELECT o.customer_id
    FROM orders o 
    JOIN orders o2 ON c.customer_id = o2.customer_id
    JOIN order_items oi on o2.order_id = oi.order_id
    WHERE(quantity * price_each) > 50000);

--Q.10--
SELECT c.customer_id, c.customer_name,
    COUNT(o.order_id) AS order_count
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name
HAVING COUNT(o.order_id) > (
        SELECT AVG(order_count)
        FROM (
          SELECT COUNT(order_id) AS order_count
              FROM orders
              GROUP BY customer_id
              ) as sub);

--Q.11--
SELECT product_id, product_name, category, price
FROM Products
WHERE price = (
    SELECT MAX(price)
    FROM Products);
-------------------------------------------------------------------------

--Window Functions--

--Q.12--
SELECT c.customer_id, c.customer_name,
      SUM(oi.quantity * oi.price_each) as total_spent,
      RANK() OVER (ORDER BY SUM(oi.quantity * oi.price_each)DESC) AS spending_rank
FROM customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN order_items oi on o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name
ORDER BY spending_rank;

--Q.13--
SELECT order_date,
       SUM(quantity * price_each) AS daily_sales,
       SUM(SUM(quantity * price_each)) OVER (ORDER BY order_date
       ) AS cumulative_sales
FROM orders o
JOIN Order_Items oi ON o.order_id = oi.order_id
GROUP BY order_date;

--Q.14--
SELECT c.customer_id, c.customer_name,
       COUNT(o.order_id) AS order_count,
       ROUND(100.0 * COUNT(o.order_id) /
            SUM(COUNT(o.order_id)) OVER (), 2) AS percentage_contribution
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY order_count DESC;

--Q.15--
SELECT * FROM (
              SELECT o.*,
                ROW_NUMBER() OVER (
                   PARTITION BY customer_id
                   ORDER BY order_date DESC
                ) AS rn
              FROM Orders o
          ) AS ranked
WHERE rn = 1;

--Q.16--
SELECT p.product_id, p.product_name, p.category, 
       SUM(oi.quantity) AS total_qty_sold,
       RANK() OVER (
            PARTITION BY p.category
            ORDER BY SUM(oi.quantity) DESC
        ) AS rank_in_category
FROM Products p  
JOIN Order_Items oi ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY p.category, rank_in_category;
-------------------------------------------------------------------------

--CTE and Case--

--Q.17--
SELECT product_id, product_name, price,
       CASE
           WHEN price >= 60000 THEN 'High'
           WHEN price BETWEEN 50000 AND 60000 THEN 'Medium'
           ELSE 'Low'
       END AS price_category
FROM products;

--Q.18--
WITH customer_spending AS (
    SELECT customer_id,
           SUM(quantity * price_each) AS total_spent
    FROM orders o
    JOIN Order_Items oi ON o.order_id = oi.order_id
    GROUP BY customer_id
    )
SELECT *
FROM customer_spending
ORDER BY total_spent DESC
offset 0 rows fetch  first 3 rows only;

--Q.19--
WITH order_counts AS (
    SELECT c.customer_id,
           COUNT(o.order_id) AS total_orders
    FROM Customers c
    LEFT JOIN Orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id
    )
SELECT customer_id, total_orders,
       CASE
           WHEN total_orders > 5 THEN 'High Loyalty'
           WHEN total_orders = 5 THEN 'Medium Loyalty'
           ELSE 'Low Loyalty'
       END AS loyalty_status
FROM order_counts;

--Q.20--
WITH monthly_sales AS (
    SELECT CAST(FORMAT(order_date, 'YYYY-MM') AS CHAR(30)) AS yr_month,
           SUM(quantity * price_each) AS revenue
    FROM orders o
    JOIN Order_Items oi ON o.order_id = oi.order_id
    GROUP BY FORMAT(order_date, 'YYYY-MM')
    )
SELECT yr_month, revenue,
      LAG(revenue) OVER (ORDER BY yr_month) AS prev_month_revenue,
      ROUND(100.0 * (revenue -
            LAG(revenue) OVER (ORDER BY yr_month)) /
            NULLIF(LAG(revenue) OVER (ORDER BY yr_month), 0),
        2) AS growth_percentage
FROM monthly_sales;

--Q.21--
WITH customer_spending AS (
    SELECT c.city, c.customer_id, c.customer_name,
          SUM(oi.quantity * oi.price_each) AS total_spent,
          RANK() OVER (
              PARTITION BY c.city
              ORDER BY SUM(oi.quantity * oi.price_each) DESC
          ) AS city_rank
    FROM Customers c
    JOIN orders o ON c.customer_id = o.customer_id
    JOIN Order_Items oi ON o.order_id = oi.order_id
    GROUP BY c.city, c.customer_id, c.customer_name
    )
SELECT *
FROM customer_spending
WHERE city_rank <= 2
ORDER BY city, city_rank;
-------------------------------------------------------------------------

--Miscellaneous Advanced Joins and Aggregations--

--Q.22--
SELECT TOP 3 
    c.city, s.shipper_id, s.shipper_name,
    SUM(quantity * price_each) AS total_revenue
FROM orders o
JOIN Order_Items oi ON o.order_id = oi.order_id
JOIN customers c ON o.customer_id = c.customer_id
JOIN shippers s ON o.shipper_id = s.shipper_id
GROUP BY c.city, s.shipper_id, s.shipper_name
ORDER BY total_revenue DESC;

--Q.23--
SELECT o.order_id, c.customer_name, p.product_name, 
s.supplier_name, sh.shipper_name
FROM Orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN Order_Items oi ON o.order_id = oi.order_id
JOIN Products p ON oi.product_id = p.product_id
JOIN suppliers s ON p.supplier_id = s.supplier_id
JOIN shippers sh ON o.shipper_id = sh.shipper_id;

--Q.24--
SELECT s.supplier_id, s.supplier_name,
       SUM(oi.quantity * oi.price_each) AS total_sales,
       ROUND(AVG(oi.quantity * oi.price_each), 2) AS avg_order_value,
       COUNT(DISTINCT oi.order_id) AS num_orders
FROM suppliers s
JOIN products p ON s.supplier_id = p.supplier_id
JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY s.supplier_id, s.supplier_name;

--Q.25--
SELECT p.category,
       SUM(quantity * price_each) AS category_revenue,
       ROUND(
       100.0 * SUM(quantity * price_each) / 
       (SELECT SUM(quantity * price_each) FROM order_items),
       2) AS total_percentage
FROM products p
JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.category
HAVING SUM(quantity * price_each) >
       0.3 * (SELECT SUM(quantity * price_each)
              FROM Order_Items)
ORDER BY total_percentage DESC;


 
 
 
 
 
 
 
 
 